#!/bin/bash
# Display Message
figlet -c SMACK Energy Forecasting
figlet -cf digital IP Config
# Configure IP Here
#
#	......
#